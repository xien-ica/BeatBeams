package xien.ica.beatbeams.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockColorRegistry;
import net.minecraft.client.color.block.BlockTintSource;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraft.core.BlockPos;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import xien.ica.beatbeams.Beatbeams;
import xien.ica.beatbeams.block.MusicBeaconBlock;
import xien.ica.beatbeams.block.MusicBeaconBlockEntity;
import xien.ica.beatbeams.block.WireBlock;
import xien.ica.beatbeams.client.gui.MusicBeaconScreen;
import xien.ica.beatbeams.client.render.MusicBeaconBeamRenderer;
import xien.ica.beatbeams.net.AudioLinkClient;

import java.util.List;

public class BeatbeamsClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        BlockEntityRenderers.register(Beatbeams.MUSIC_BEACON_BLOCK_ENTITY, MusicBeaconBeamRenderer::new);
        AudioLinkClient.get().start();

        // Wire tint: black when off, bright red when on (redstone-dust style)
        BlockColorRegistry.register(List.of(new BlockTintSource() {
            @Override
            public int colorInWorld(BlockState state, BlockAndTintGetter level, BlockPos pos) {
                return state.getValue(WireBlock.POWERED) ? 0xFFFF0000 : 0xFF000000;
            }

            @Override
            public int color(BlockState state) {
                return state.getValue(WireBlock.POWERED) ? 0xFFFF0000 : 0xFF000000;
            }
        }), Beatbeams.WIRE_BLOCK);

        MusicBeaconBlock.clientOpenScreen = pos -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) return;
            if (mc.level.getBlockEntity(pos) instanceof MusicBeaconBlockEntity be) {
                mc.gui.setScreen(new MusicBeaconScreen(be));
            }
        };
    }
}
